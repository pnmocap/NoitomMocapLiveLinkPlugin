// Copyright Epic Games, Inc. All Rights Reserved.

#include "MocapApiAdapter.h"
#include "Core.h"
#include "Modules/ModuleManager.h"
#include "Interfaces/IPluginManager.h"
#include "Misc/Paths.h"
#include "Misc/MessageDialog.h"
#include "HAL/PlatformProcess.h"
#include "../../MocapApi/include/MocapApi.h"

#define LOCTEXT_NAMESPACE "FMocapApiAdapterModule"

void FMocapApiAdapterModule::StartupModule()
{
	// This code will execute after your module is loaded into memory; the exact timing is specified in the .uplugin file per-module
	FString NeuronLiveLinkPlugin = TEXT("NeuronLiveLink");//Change this string to the name of the main plugin directory
	FString NeuronBaseDir = IPluginManager::Get().FindPlugin(NeuronLiveLinkPlugin)->GetBaseDir();
	FString NeuronLibraryPath;

#if PLATFORM_WINDOWS
	NeuronLibraryPath = FPaths::Combine(*NeuronBaseDir, TEXT("Source/ThirdParty/MocapApi/bin/x64/MocapApi.dll"));
	//"Source/MocapApi/bin/x64/MocapApi.dll" Original Path
	//"Source/ThirdParty/MocapApi/bin/x64/MocapApi.dll" Second Test
	//"Source/Binaries/ThirdParty/MocapApi/bin/x64/MocapApi.dll" Third Test
#endif // PLATFORM_WINDOWS

	MocapApiLibraryHandle = !NeuronLibraryPath.IsEmpty() ? FPlatformProcess::GetDllHandle(*NeuronLibraryPath) : nullptr;

	if (MocapApiLibraryHandle)
	{
		UE_LOG(LogTemp, Log, TEXT("MocapApi lib loaded success."));
		FMessageDialog::Open(EAppMsgType::Ok, LOCTEXT("ThirdPartyLibrarySuccess", "Third Party MocapApi.dll Loaded Succesfully!"));
	}
	else
	{
		FMessageDialog::Open(EAppMsgType::Ok, LOCTEXT("ThirdPartyLibraryError", "Failed to load MocapApi.dll."));
	}
}

void FMocapApiAdapterModule::ShutdownModule()
{
	// This function may be called during shutdown to clean up your module.  For modules that support dynamic reloading,
	// we call this function before unloading the module.
	if (MocapApiLibraryHandle)
    {
        FPlatformProcess::FreeDllHandle(MocapApiLibraryHandle);
        MocapApiLibraryHandle = nullptr;
    }
	
}

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FMocapApiAdapterModule, MocapApiAdapter)