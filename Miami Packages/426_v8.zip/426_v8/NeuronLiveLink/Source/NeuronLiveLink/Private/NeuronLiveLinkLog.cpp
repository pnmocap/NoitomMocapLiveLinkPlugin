#include "NeuronLiveLinkLog.h"

DEFINE_LOG_CATEGORY(LogNeuronLiveLink)
